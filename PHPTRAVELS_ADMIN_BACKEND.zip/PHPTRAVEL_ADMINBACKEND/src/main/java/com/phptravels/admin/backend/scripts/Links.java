package com.phptravels.admin.backend.scripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Links {

	WebDriver driver;
	@FindBy(xpath="//*[text()='Bookings']")
    private WebElement bookings;
    @FindBy(xpath="//*[@href=\"https://phptravels.net/api/admin/bookings/paid\"]")
    private WebElement paidbookings;    
    @FindBy(xpath="//*[@id=\"data\"]/tbody/tr[1]/td[14]/a")
    private WebElement invoice;
    
    @FindBy(xpath="//*[@href=\"https://phptravels.net/api/admin/bookings/cancelled\"]")
    private WebElement cancelledbookings;
    @FindBy(xpath="//*[@id=\"data\"]/tbody/tr[1]/td[15]/button")
    private WebElement delete;
    
    @FindBy(xpath="//*[@href=\"https://phptravels.net/api/admin/bookings/pending\"]")
    private WebElement pendingsbookings;
    
    @FindBy(xpath="//*[@href=\"https://phptravels.net/api/admin/bookings/confirmed\"]")
    private WebElement confirmedbookings;
    
    @FindBy(id="booking_status")
    private WebElement bookingstatus;
    
    @FindBy(xpath="//*[text()='Website']")
    private WebElement website;
    
  
    public Links(WebDriver driver){
        this.driver = driver;
        
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
    }
    
    public void clickBookings() {
    	bookings.click();
    }
    
    public void clickpaidBookings() {
    	
    	paidbookings.click();
    }
    
    public void clickInvoice() {
    	
    	invoice.click();
    }
    
    public void clickcancelledBooking() {
    	
    	cancelledbookings.click();
    }
    
   public void clickDelete() {
    	
	delete.click();
    }
   public void clickpendingBooking() {
	   
	   
	   pendingsbookings.click();
   }
   
   public void clickWebsite() {
	   
	   
	  website.click();
   }
   
   public void selectConfirmed() {
	   	
	   	Select drpbookingstatus=new Select(bookingstatus);
	   	drpbookingstatus.selectByVisibleText("Confirmed");
	   	
	}
   
   public String getPendingBookings() {
	   
	   
	   return pendingsbookings.getText();
   }
   
   public String getConfirmedBookings() {
	   
	   
	   return confirmedbookings.getText();
   }
   
   public String getCancelledBookings() {
	   
	   
	   return cancelledbookings.getText();
   }
  
}   
