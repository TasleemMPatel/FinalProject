package com.phptravels.admin.backend.utils;

import org.testng.annotations.DataProvider;

public class DataUtils {

	@DataProvider(name="dp1")
	public Object[][] getData() {
		
		return new Object[][] {{"admin@phptravels.com","demoadmin"}};
	}
}
