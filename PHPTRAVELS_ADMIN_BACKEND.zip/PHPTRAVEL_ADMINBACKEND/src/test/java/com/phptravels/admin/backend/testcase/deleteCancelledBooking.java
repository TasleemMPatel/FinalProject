package com.phptravels.admin.backend.testcase;

import java.util.ArrayList;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravels.admin.backend.scripts.Links;
import com.phptravels.admin.backend.scripts.Login;
import com.phptravels.admin.backend.utils.AppUtils;
import com.phptravels.admin.backend.utils.DataUtils;

public class deleteCancelledBooking extends AppUtils{

	@Test(dataProvider="dp1",dataProviderClass=DataUtils.class,priority=5)
	public void delete(String username,String password) throws InterruptedException {
				
		
	    Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(2000);
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Links link=new Links(driver);
		
		link.clickBookings();
		
		Thread.sleep(2000);
		//Creating softAssert object
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(driver.getTitle(), "All Bookings View");
		
		link.clickcancelledBooking();
		softAssert.assertEquals(driver.getTitle(), "cancelled Bookings View");
		String entireCancelBookingsStr=link.getCancelledBookings();
		String cancelBookingsStr=entireCancelBookingsStr.substring(0, 2);
		int cancelBookings=Integer.parseInt(cancelBookingsStr.trim());
		if(cancelBookings != 0) {
			
		  link.clickDelete();
		  Thread.sleep(3000);
		  driver.switchTo().alert().accept();
		  
		}else {
			
			System.out.println("No cancelled bookings,proceed with test");
		}
		
		softAssert.assertAll();
		
	}

}
