package com.phptravels.admin.backend.testcase;

import java.util.ArrayList;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravels.admin.backend.scripts.Links;
import com.phptravels.admin.backend.scripts.Login;
import com.phptravels.admin.backend.utils.AppUtils;
import com.phptravels.admin.backend.utils.DataUtils;

public class displayInvoice extends AppUtils{
	
	@Test(dataProvider="dp1",dataProviderClass=DataUtils.class,priority=4)
	public void display(String username,String password) throws InterruptedException {
				
		
	    Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(2000);
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Links link=new Links(driver);
		
		link.clickBookings();
		
		Thread.sleep(2000);
		//Creating softAssert object
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(driver.getTitle(), "All Bookings View");
		
		link.clickpaidBookings();
		softAssert.assertEquals(driver.getTitle(), "paid Bookings View");
		
		link.clickInvoice();
		Thread.sleep(3000);
		
		ArrayList<String> wid=new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(wid.get(1));
		Thread.sleep(3000);
		System.out.println("title="+driver.getTitle());
		System.out.println("isDispalyed"+driver.getPageSource().contains("Booking Invoice"));
		softAssert.assertTrue(driver.getPageSource().contains("Booking Invoice"));
		driver.close();
		driver.switchTo().window(wid.get(0));
		System.out.println("title=after moving"+driver.getTitle());
		softAssert.assertAll();
		
	}

}
