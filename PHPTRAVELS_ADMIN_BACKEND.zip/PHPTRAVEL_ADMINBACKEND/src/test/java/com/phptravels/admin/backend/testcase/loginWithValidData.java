package com.phptravels.admin.backend.testcase;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravels.admin.backend.scripts.Login;
import com.phptravels.admin.backend.utils.AppUtils;
import com.phptravels.admin.backend.utils.ExcelUtils;



public class loginWithValidData extends AppUtils{

String datafile = "E:\\PHPTRAVELS_ADMIN_BACKEND\\PHPTRAVEL_ADMINBACKEND\\src\\main\\resources\\testData.xlsx";
	               
	
	String datasheet = "validlogin";

	@Test(priority=1)
	public void checkLogin() throws IOException, InterruptedException
	{
		
		Login login;
		String username,password;
		
		
			username = ExcelUtils.getStringCellData(datafile, datasheet, 1, 0);
			
			password = ExcelUtils.getStringCellData(datafile, datasheet, 1, 1);
			
			System.out.println(username);
			System.out.println(password);
			login = new Login(driver);
			login.setUserName(username);
		    login.setPassword(password);
		    login.clickLogin();
		    Thread.sleep(2000);
		   		    
		    Assert.assertTrue(driver.getPageSource().contains("Dashboard"));
		   
		
	}
}
