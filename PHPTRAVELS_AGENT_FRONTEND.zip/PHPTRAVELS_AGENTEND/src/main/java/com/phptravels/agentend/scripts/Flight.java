package com.phptravels.agentend.scripts;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Flight {

	WebDriver driver;
	@FindBy(xpath="//*[@href=\"https://phptravels.net/flights\"]")
    private WebElement flights;
    @FindBy(name="from")
    private WebElement flyingfrom;    
    @FindBy(name="to")
    private WebElement destination;
    @FindBy(id="flights-search")
    private WebElement flightsearch;
    
  // private HomePage homepage; 
    public Flight(WebDriver driver){
        this.driver = driver;
        
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
    }
    
    public void clickFlights(){
    	
    	flights.click(); 
    }
    
    public void searchByOrgin() throws InterruptedException {
    	
    	JavascriptExecutor js= (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].click();", flyingfrom);
    	Thread.sleep(2000);
    	js.executeScript("arguments[0].value='DXB - Dubai Intl - Dubai'", flyingfrom);
    	
    	js.executeScript("arguments[0].click();", destination);
    	
    	js.executeScript("arguments[0].value='RML - Colombo Ratmalana - Colombo'", destination);
    	
    	//String text = (String) js.executeScript("return arguments[0].value", searchByCity);  
    	//System.out.println(text);  
    	
    	
    }
    
public void clickSearch(){
    
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("arguments[0].click();", flightsearch);
	//searchbtn.click(); 
    }
    
}
