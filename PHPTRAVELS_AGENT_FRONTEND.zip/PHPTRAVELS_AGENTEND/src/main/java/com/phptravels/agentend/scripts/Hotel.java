package com.phptravels.agentend.scripts;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Hotel {
	
	WebDriver driver;
	@FindBy(xpath="//*[@href=\"https://phptravels.net/hotels\"]")
    private WebElement hotels;
    @FindBy(xpath="//*[text()=' Search by City']")
    private WebElement searchByCity;    
    @FindBy(id="submit")
    private WebElement searchbtn;
    
  // private HomePage homepage; 
    public Hotel(WebDriver driver){
        this.driver = driver;
        
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
    }
    
    public void clickHotel(){
    	
    	hotels.click(); 
    }
    
    public void searchByCity(String city) throws InterruptedException {
    	
    	JavascriptExecutor js= (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].click();", searchByCity);
    	
    	System.out.println("city"+city);
    	js.executeScript("arguments[0].value='" + city + "';", searchByCity);
    	
    	//js.executeScript("arguments[0].value='Singapore'", searchByCity);
    	Thread.sleep(2000);
    	String text = (String) js.executeScript("return arguments[0].value", searchByCity);  
    	System.out.println(text);  
    	
    	
    }
    
public void clickSearch(){
    
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript("arguments[0].click();", searchbtn);
	//searchbtn.click(); 
    }
    

}
