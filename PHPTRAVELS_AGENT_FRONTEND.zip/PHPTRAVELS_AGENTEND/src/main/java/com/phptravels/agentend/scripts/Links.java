package com.phptravels.agentend.scripts;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Links {
	
	WebDriver driver;
	@FindBy(xpath="//a[@href=\"https://phptravels.net/account/bookings\"]")
    private WebElement bookings;
    @FindBy(xpath="//a[@href=\"https://phptravels.net/account/add_funds\"]")
    private WebElement addFunds;    
    @FindBy(xpath="//a[@href=\"https://phptravels.net/account/profile\"]")
    private WebElement profile;
    @FindBy(xpath="//a[@href=\"https://phptravels.net/account/logout\"]")
    private WebElement logout;
    
	@FindBy(xpath="//*[@href=\"https://phptravels.net/visa\"]")
    private WebElement visa;
	
	@FindBy(xpath="//*[@href=\"https://phptravels.net/blog\"]")
    private WebElement blog;
	
	@FindBy(xpath="//*[@href=\"https://phptravels.net/offers\"]")
    private WebElement offers;
    
    public Links(WebDriver driver){
    	
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public void clickBookings(){
    	
    	JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();", bookings);
    	
    	  
    }

    public void clickAddFunds(){
    	
    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].click();", addFunds);
    	
    	  
    }
    
    public void clickProfile()
    {
    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].click();", profile);
    	
    }
    
    public void clickLogOut()
    {
    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].click();", logout);
    	
    }
    
    public void clickVisa()
    {
    	
    	visa.click();
    }
    
    public void clickBlog()
    {
    	
    	blog.click();
    }
    
    public void clickOffers()
    {
    	
    	offers.click();
    }
    

}
