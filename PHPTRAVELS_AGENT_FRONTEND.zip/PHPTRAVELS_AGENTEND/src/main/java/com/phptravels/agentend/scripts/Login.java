package com.phptravels.agentend.scripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Login {
	
	
	WebDriver driver;
	@FindBy(name="email")
    private WebElement username;
    @FindBy(name="password")
    private WebElement password;    
    @FindBy(xpath="//*[@id=\"fadein\"]/div[4]/div/div[2]/div[2]/div/form/div[3]/button/span[1]")
    private WebElement login;
    
  // private HomePage homepage; 
    public Login(WebDriver driver){
        this.driver = driver;
        
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
    }
    
    public void setUserName(String strUserName){
    	username.clear();
    	username.sendKeys(strUserName);     
    }

    public void setPassword(String strPassword){
    	password.clear();
        password.sendKeys(strPassword);
    }
    
    public void clickLogin()
    {
    	login.click();
    }


}
