package com.phptravels.agentend.utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AppUtils {
	
	public static WebDriver driver;
	//public static ExcelReader excel = new ExcelReader(PropertyUtilFile.getValueForKey("datafile"));	
		
		@BeforeMethod
		public static void launchBrowser() throws Throwable {
			String browser = PropertyUtilFile.getValueForKey("Browser").toLowerCase();
			
			
			switch(browser) {
			case "chrome" : WebDriverManager.chromedriver().setup();
							driver = new ChromeDriver();
							break;
			case "firefox" : WebDriverManager.firefoxdriver().setup();
							driver = new FirefoxDriver();
							break;
			default : System.out.println("Browser Value is Not Matching");
			}
			
			if(driver!=null) {
				driver.manage().deleteAllCookies();
				driver.manage().window().maximize();
				appUrl(driver);
			}
		}
		
		public static void appUrl(WebDriver driver)throws Throwable

		{

		driver.get(PropertyUtilFile.getValueForKey("url"));

		}

		@AfterMethod
		public static void closeBrowser() {
			System.out.println("Aftertest");
			driver.close();
			//driver.quit();
		}
		
		@AfterSuite
		public static void EndBrowser() {
			System.out.println("AfterSuite");
			driver.quit();
		}

}
