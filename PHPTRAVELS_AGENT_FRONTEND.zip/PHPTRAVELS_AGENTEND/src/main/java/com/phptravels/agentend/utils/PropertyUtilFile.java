package com.phptravels.agentend.utils;

import java.util.ResourceBundle;

public class PropertyUtilFile {
	
	public static String getValueForKey(String key)
	{

		ResourceBundle rb = ResourceBundle.getBundle("config");
		return rb.getString(key);
	}
}

