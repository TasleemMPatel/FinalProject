package com.phptravels.agentend.testcases;

import java.io.IOException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravels.agentend.scripts.Flight;
import com.phptravels.agentend.scripts.Login;
import com.phptravels.agentend.utils.AppUtils;
import com.phptravels.agentend.utils.DataUtils;

public class changeCurrency extends AppUtils{

	@Test(priority=1,dataProvider="dp1",dataProviderClass=DataUtils.class)
	public void changeUSDtoINR(String username,String password) throws IOException, InterruptedException
	{
		System.out.println("searchHotelByCity");
		
				
		Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(2000);
			
		driver.findElement(By.id("currency")).click();;
		JavascriptExecutor je = (JavascriptExecutor) driver;
        WebElement element = driver.findElement(By.xpath("//*[@href=\"https://phptravels.net/currency-INR\"]"));
        je.executeScript("arguments[0].scrollIntoView(true);",element);
        
        Thread.sleep(4000);
        element.click();
        Thread.sleep(4000);	
		System.out.println(driver.getCurrentUrl());
		ArrayList<String> wid=new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(wid.get(0));
		je.executeScript("window.scrollBy(0,700)");
		System.out.println(driver.getPageSource().contains("INR"));
		Assert.assertTrue(driver.getPageSource().contains("INR"));
		Thread.sleep(4000);
		    
		   
		    
		
		
	}

}
