package com.phptravels.agentend.testcases;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravels.agentend.scripts.Links;
import com.phptravels.agentend.scripts.Login;
import com.phptravels.agentend.utils.AppUtils;
import com.phptravels.agentend.utils.DataUtils;

public class checkLinks extends AppUtils {
	
	@Test(dataProvider="dp1",dataProviderClass=DataUtils.class,priority=3)
	public void logOut(String username,String password) throws InterruptedException {
		
		
	    Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(2000);
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Links link=new Links(driver);
		
		link.clickBookings();
		Thread.sleep(2000);
		//Creating softAssert object
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(driver.getTitle(), "Bookings - PHPTRAVELS");
		
		link.clickAddFunds();
		Thread.sleep(2000);
		System.out.println("title="+driver.getTitle());
		softAssert.assertEquals(driver.getTitle(), "Add Funds - PHPTRAVELS");
		
		link.clickProfile();
		Thread.sleep(2000);
		System.out.println("title="+driver.getTitle());
		softAssert.assertEquals(driver.getTitle(), "Profile - PHPTRAVELS");
		
		link.clickLogOut();
		Thread.sleep(2000);
		System.out.println("title="+driver.getTitle());
		softAssert.assertEquals(driver.getTitle(), "Login - PHPTRAVELS");
		
		softAssert.assertAll();
	}

}
