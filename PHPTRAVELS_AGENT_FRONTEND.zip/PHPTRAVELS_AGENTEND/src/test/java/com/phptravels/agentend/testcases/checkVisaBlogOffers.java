package com.phptravels.agentend.testcases;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravels.agentend.scripts.Links;
import com.phptravels.agentend.scripts.Login;
import com.phptravels.agentend.utils.AppUtils;
import com.phptravels.agentend.utils.DataUtils;

public class checkVisaBlogOffers extends AppUtils{

	@Test(dataProvider="dp1",dataProviderClass=DataUtils.class,priority=3)
	public void checkVBO(String username,String password) throws InterruptedException {
		
		
	    Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(2000);
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Links link=new Links(driver);
		
		link.clickVisa();
		Thread.sleep(2000);
		//Creating softAssert object
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(driver.getTitle(), "Submit Visa - PHPTRAVELS");
		
		link.clickBlog();
		Thread.sleep(2000);
		System.out.println("title="+driver.getTitle());
		softAssert.assertEquals(driver.getTitle(), "Blog - PHPTRAVELS");
		
		link.clickOffers();
		Thread.sleep(2000);
		System.out.println("title="+driver.getTitle());
		softAssert.assertEquals(driver.getTitle(), "Offers - PHPTRAVELS");
		
		
		
		softAssert.assertAll();
	}

}
