package com.phptravels.agentend.testcases;

import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravels.agentend.scripts.Login;
import com.phptravels.agentend.utils.AppUtils;
import com.phptravels.agentend.utils.ExcelUtils;

public class loginWithInvalidData extends AppUtils{
	
	String datafile = "E:\\PHPTRAVELS_AGENT_FRONTEND\\PHPTRAVELS_AGENTEND\\src\\main\\resources\\testData.xlsx";
	String datasheet = "Invalidlogin";

	@Test(priority=1)
	public void checkInvalidLogin() throws IOException, InterruptedException
	{
		
		System.out.println("inside login with invalid data");
		
		int rowcount = ExcelUtils.getRowCount(datafile, datasheet);
		
		Login login; 
		
		String username,password;
		
		for(int i=1;i<=rowcount;i++)
		{
			try {
			username = ExcelUtils.getStringCellData(datafile, datasheet, i, 0);
			password = ExcelUtils.getStringCellData(datafile, datasheet, i, 1);
			login = new Login(driver);
			login.setUserName(username);
		    login.setPassword(password);
            
		    Thread.sleep(2000);
            
		    login.clickLogin();
		    Thread.sleep(3000);
		    
		  /* if(username.isEmpty()) {
		    	//System.out.println(username);
		    	Assert.assertTrue(driver.getPageSource().contains("Wrong credentials") );
		    }else if(password.isEmpty()) {
		    	//System.out.println(password);
		    	Assert.assertTrue(driver.getPageSource().contains("The Password field is required") );
		    	
		    }else  {
		    	//System.out.println("lastelse"+username);
		    	Assert.assertTrue(driver.getPageSource().contains("The Email field must contain a valid email address") || driver.getPageSource().contains("Invalid Login Credentials"));
		    	
		    }	*/	    
		   	    
		    
		    
		    } catch (UnhandledAlertException f) {
		        try {
		            Alert alert = driver.switchTo().alert();
		            String alertText = alert.getText();
		            System.out.println(alertText);
		            alert.accept();
		             } catch (NoAlertPresentException e) {
		            e.printStackTrace();
		            System.out.println("No alert found on page, proceed with test.");
		            
		        }
		    }
			
		}
		
		
		
	}


}
