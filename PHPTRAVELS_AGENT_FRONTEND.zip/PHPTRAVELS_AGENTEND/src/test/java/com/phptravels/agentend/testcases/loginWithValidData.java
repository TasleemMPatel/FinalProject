package com.phptravels.agentend.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravels.agentend.scripts.Login;
import com.phptravels.agentend.utils.ExcelUtils;
import com.phptravels.agentend.utils.AppUtils;

public class loginWithValidData extends AppUtils{
	
	
String datafile = "E:\\PHPTRAVELS_AGENT_FRONTEND\\PHPTRAVELS_AGENTEND\\src\\main\\resources\\testData.xlsx";
	               
	
	String datasheet = "validlogin";

	@Test(priority=1)
	public void checkLogin() throws IOException, InterruptedException
	{
		System.out.println("inside login with valid data");
		int rowcount = ExcelUtils.getRowCount(datafile, datasheet);
		System.out.println(rowcount);
		Login login;
		//Logout logout = new Logout(driver);
		String username,password;
		
		for(int i=1;i<=rowcount;i++)
		{
			username = ExcelUtils.getStringCellData(datafile, datasheet, i, 0);
			if(username.equals("admin")) {
				password = ((int)ExcelUtils.getNumericCellData(datafile, datasheet, i, 1))+"";
				System.out.println(password);
			}
			else {
				password = ExcelUtils.getStringCellData(datafile, datasheet, i, 1);
			}
			System.out.println(username);
			System.out.println(password);
			login = new Login(driver);
			login.setUserName(username);
		    login.setPassword(password);
		    login.clickLogin();
		    Thread.sleep(2000);
		    //Boolean res;
		    System.out.println(driver.getCurrentUrl());
		    
		    if(driver.getCurrentUrl().equals("https://phptravels.net/account/dashboard") ) {
		    //res = true;
			//Assert.assertTrue(res);
			//if(res)
			
				ExcelUtils.setCellData(datafile, datasheet, i, 2, "Pass");
				
				//ExcelUtils.fillGreenColor(datafile, datasheet, i, 2);
			}else
			{
				ExcelUtils.setCellData(datafile, datasheet, i, 2, "Fail");
				//ExcelUtils.fillRedColor(datafile, datasheet, i, 2);
			}
		    Assert.assertEquals(driver.getCurrentUrl(), "https://phptravels.net/account/dashboard");
		   //logout.clickLogout();
			
		}
		
		
		
	}


}
