package com.phptravels.agentend.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravels.agentend.scripts.Hotel;
import com.phptravels.agentend.scripts.Login;
import com.phptravels.agentend.utils.AppUtils;
import com.phptravels.agentend.utils.DataUtils;
import com.phptravels.agentend.utils.ExcelUtils;

public class searchHotel extends AppUtils{

    String datafile = "E:\\PHPTRAVELS_AGENT_FRONTEND\\PHPTRAVELS_AGENTEND\\src\\main\\resources\\testData.xlsx";

	String datasheet = "Cityname";

	@Test(priority=1,dataProvider="dp1",dataProviderClass=DataUtils.class)
	public void searchHotelByCity(String username,String password) throws IOException, InterruptedException
	{
		System.out.println("searchHotelByCity");
		int rowcount = ExcelUtils.getRowCount(datafile, datasheet);
		System.out.println(rowcount);
		Hotel hotelsearch;
		//Logout logout = new Logout(driver);
		String cityname;
		 Login login= new Login(driver);
			login.setUserName(username);
			login.setPassword(password);
			login.clickLogin();
			Thread.sleep(2000);
		
			cityname = ExcelUtils.getStringCellData(datafile, datasheet, 1, 0);
			
			System.out.println(cityname);
			
			hotelsearch = new Hotel(driver);
			hotelsearch.clickHotel();
			SoftAssert sAssert=new SoftAssert();
			sAssert.assertEquals(driver.getTitle(),"Search Hotels - PHPTRAVELS" );
			hotelsearch.searchByCity(cityname);
			hotelsearch.clickSearch();
		    Thread.sleep(2000);
		    
		    sAssert.assertTrue(driver.getPageSource().contains("Search Hotels"));
		    
		    sAssert.assertAll();
		    
			
		}
		
	
		
	}


