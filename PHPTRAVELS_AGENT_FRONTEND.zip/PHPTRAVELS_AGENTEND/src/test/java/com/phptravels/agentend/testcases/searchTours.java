package com.phptravels.agentend.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravels.agentend.scripts.Flight;
import com.phptravels.agentend.scripts.Login;
import com.phptravels.agentend.scripts.Tours;
import com.phptravels.agentend.utils.AppUtils;
import com.phptravels.agentend.utils.DataUtils;

public class searchTours extends AppUtils{

	@Test(priority=1,dataProvider="dp1",dataProviderClass=DataUtils.class)
	public void searchToursByCity(String username,String password) throws IOException, InterruptedException
	{
		System.out.println("searchHotelByCity");
		
		Tours toursearch;
		
		Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(2000);
			
		 toursearch = new Tours(driver);
		 toursearch.clickTours();
		 SoftAssert sAssert=new SoftAssert();
		 sAssert.assertEquals(driver.getTitle(),"Search Tours - PHPTRAVELS" );
		 toursearch.searchForTourByCity();
		 toursearch.clickSearch();
		Thread.sleep(2000);
			
		System.out.println(driver.getCurrentUrl());
		    
		System.out.println("isDispalyed"+driver.getPageSource().contains("Search Tours"));   
		    
		sAssert.assertTrue(driver.getPageSource().contains("Search Tours"));
		sAssert.assertAll();
		
	}
}
