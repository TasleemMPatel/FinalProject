package com.phptravels.frontend.scripts;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.idealized.Javascript;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Address {

	
	WebDriver driver;
	@FindBy(name="address1")
    private WebElement address1;
    @FindBy(name="address2")
    private WebElement address2;    
    @FindBy(xpath="//*[text()='Update Profile']")
    private WebElement updatebtn;
    
  // private HomePage homepage; 
    public Address(WebDriver driver){
        this.driver = driver;
       
        //This initElements method will create all WebElements
        PageFactory.initElements(driver, this);
    }
    
    public void setAddress1(String strAdd1){
    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("window.scrollBy(0,700)");
    	address1.clear();
    	address1.sendKeys(strAdd1);     
    }

    public void setAddress2(String strAdd2){
    	address2.clear();
    	address2.sendKeys(strAdd2);
    }
    
    public void clickUpdate()
    {
    	
    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	
    	js.executeScript("arguments[0].click();", updatebtn);
    }

}
