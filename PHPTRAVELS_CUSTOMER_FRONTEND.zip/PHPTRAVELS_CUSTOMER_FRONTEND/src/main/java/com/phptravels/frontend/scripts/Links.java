package com.phptravels.frontend.scripts;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Links {
	
	
	

		WebDriver driver;
		@FindBy(xpath="//a[@href=\"https://phptravels.net/account/bookings\"]")
	    private WebElement bookings;
	    @FindBy(xpath="//a[@href=\"https://phptravels.net/account/add_funds\"]")
	    private WebElement addFunds;    
	    @FindBy(xpath="//a[@href=\"https://phptravels.net/account/profile\"]")
	    private WebElement profile;
	    @FindBy(xpath="//a[@href=\"https://phptravels.net/account/logout\"]")
	    private WebElement logout;
	    
	    @FindBy(xpath="//*[@value=\"paypal\"]")
	    private WebElement paypalradiobtn;
	    @FindBy(xpath="//*[text()='Pay Now ']")
	    private WebElement paybtn;
	    
	    @FindBy(xpath="//*[text()=' View Voucher']")
	    private WebElement voucher;
	   // @FindBy(xpath="//*[text()='Booking Invoice                            ']")
	   // private WebElement vouchertext;
	    
	  // private HomePage homepage; 
	    public Links(WebDriver driver){
	    	
	        this.driver = driver;
	        PageFactory.initElements(driver, this);
	    }
	    
	    public void clickBookings(){
	    	
	    	JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].click();", bookings);
	    	//bookings.click();
	    	  
	    }

	    public void clickAddFunds(){
	    	
	    	JavascriptExecutor js = (JavascriptExecutor)driver;
	    	js.executeScript("arguments[0].click();", addFunds);
	    	//addFunds.click();
	    	  
	    }
	    public void clickProfile()
	    {
	    	JavascriptExecutor js = (JavascriptExecutor)driver;
	    	js.executeScript("arguments[0].click();", profile);
	    	//profile.click();
	    }
	    
	    public void clickLogOut()
	    {
	    	JavascriptExecutor js = (JavascriptExecutor)driver;
	    	js.executeScript("arguments[0].click();", logout);
	    	//logout.click();
	    }
	    
	    public void clickPaypalradio()
	    {
	    	JavascriptExecutor js = (JavascriptExecutor)driver;
	    	js.executeScript("window.scrollBy(0,600)");
	    	js.executeScript("arguments[0].click();", paypalradiobtn);
	    	//paypalradiobtn.click();
	    }
	    
	    public void clickPaybtn()
	    {
	    	JavascriptExecutor js = (JavascriptExecutor)driver;
	    	
	    	js.executeScript("arguments[0].click();", paybtn);
	    	//paypalradiobtn.click();
	    }
	    
	    public void clickVoucher()
	    {
	    	JavascriptExecutor js = (JavascriptExecutor)driver;
	    	
	    	js.executeScript("arguments[0].click();", voucher);
	    	//paypalradiobtn.click();
	    }
	    
	    
	}



