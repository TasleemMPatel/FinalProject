package com.phptravels.frontend.utils;
import java.lang.reflect.Method;

import org.testng.annotations.DataProvider;


public class DataUtils extends AppUtils {
	
		@DataProvider(name="dp1")
		public Object[][] getData() {
			
			return new Object[][] {{"user@phptravels.com","demouser"}};
		
			//String sheetName = m.getName();
			//System.out.println(sheetName);
			
			/*int rows = excel.getRowCount(sheetName);
			int cols = excel.getColumnCount(sheetName);
				
			Object[][] data = new Object[rows-1][cols];
		
			
			for(int rowNum=2; rowNum<=rows; rowNum++) {
				
				for(int colNum=0; colNum<cols;colNum++) {
					
					data[rowNum-2][colNum] = excel.getCellData(sheetName, colNum, rowNum);
					
				}
				
			}
			
			
			return data;*/
			
			
		}
		

	}



