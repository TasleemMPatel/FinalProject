package com.phptravels.frontend.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravels.frontend.scripts.Links;
import com.phptravels.frontend.scripts.Login;
import com.phptravels.frontend.utils.AppUtils;
import com.phptravels.frontend.utils.DataUtils;

public class checkLogout extends AppUtils{
	
	@Test(dataProvider="dp1",dataProviderClass=DataUtils.class,priority=3)
	public void logOut(String username,String password) throws InterruptedException {
		
		
	    Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(2000);
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Links link=new Links(driver);
		
		
		link.clickLogOut();
		Thread.sleep(2000);
		System.out.println("title="+driver.getTitle());
		Assert.assertEquals(driver.getTitle(), "Login - PHPTRAVELS");
		
		
	}

}
