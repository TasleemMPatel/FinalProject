package com.phptravels.frontend.testcases;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravels.frontend.scripts.Links;
import com.phptravels.frontend.scripts.Login;
import com.phptravels.frontend.utils.AppUtils;
import com.phptravels.frontend.utils.DataUtils;

public class displayVoucher extends AppUtils{

	@Test(dataProvider="dp1",dataProviderClass=DataUtils.class,priority=4)
	public void display(String username,String password) throws InterruptedException {
		System.out.println("inside display voucher");
		
		
	    Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(2000);
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Links link=new Links(driver);
		
		link.clickBookings();
		
		Thread.sleep(2000);
		  //Creating softAssert object
		   SoftAssert softAssert = new SoftAssert();
		   softAssert.assertEquals(driver.getTitle(), "Bookings - PHPTRAVELS");
		   
		link.clickVoucher();
		Thread.sleep(3000);
		System.out.println("title="+driver.getTitle());
		ArrayList<String> wid=new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(wid.get(1));
		Thread.sleep(3000);
		System.out.println("title="+driver.getTitle());
		System.out.println("isDispalyed"+driver.getPageSource().contains("Booking Invoice"));
		softAssert.assertTrue(driver.getPageSource().contains("Booking Invoice"));
		driver.close();
		driver.switchTo().window(wid.get(0));
		System.out.println("title=after moving"+driver.getTitle());
		softAssert.assertAll();
		
	}
}
