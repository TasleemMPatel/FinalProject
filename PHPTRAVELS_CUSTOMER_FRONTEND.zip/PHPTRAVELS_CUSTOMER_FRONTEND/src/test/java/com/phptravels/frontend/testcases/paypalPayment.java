package com.phptravels.frontend.testcases;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravels.frontend.scripts.Links;
import com.phptravels.frontend.scripts.Login;
import com.phptravels.frontend.utils.AppUtils;
import com.phptravels.frontend.utils.DataUtils;

public class paypalPayment extends AppUtils{
	
	@Test(dataProvider="dp1",dataProviderClass=DataUtils.class,priority=1)
	public void doPayment(String username,String password) throws InterruptedException {
		System.out.println("username"+username);
		
	    Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		Thread.sleep(2000);
		login.clickLogin();
		Thread.sleep(2000);
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Links link=new Links(driver);
		
		
		SoftAssert softAssert = new SoftAssert();
		   
		   
		link.clickAddFunds();
		Thread.sleep(2000);
		System.out.println("title="+driver.getTitle());
		//softAssert.assertEquals(driver.getTitle(), "Add Funds - PHPTRAVELS");
		
		link.clickPaypalradio();
		Thread.sleep(2000);
		
		link.clickPaybtn();
		Thread.sleep(2000);
		System.out.println("title="+driver.getTitle());
		driver.switchTo().frame(0);
		//driver.findElement(By.className("paypal-button-row")).click();
		driver.findElement(By.xpath("//*[@id=\"buttons-container\"]/div/div")).click();
		driver.switchTo().defaultContent();
		Thread.sleep(4000);
		//driver.findElement(By.linkText("Click to Continue")).click();
		softAssert.assertAll();
		
	}

}
