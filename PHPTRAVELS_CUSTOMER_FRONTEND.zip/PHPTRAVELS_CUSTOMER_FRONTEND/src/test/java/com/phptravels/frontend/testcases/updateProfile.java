package com.phptravels.frontend.testcases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravels.frontend.scripts.Address;
import com.phptravels.frontend.scripts.Links;
import com.phptravels.frontend.scripts.Login;
import com.phptravels.frontend.utils.AppUtils;
import com.phptravels.frontend.utils.DataUtils;
import com.phptravels.frontend.utils.*;

public class updateProfile extends AppUtils{

    String datafile = "E:\\PHPTRAVELS_CUSTOMER_FRONTEND\\PHPTRAVELS_CUSTOMER_FRONTEND\\src\\main\\resources\\testData.xlsx";
	               
	String datasheet = "Address";

	@Test(dataProvider="dp1",dataProviderClass=DataUtils.class,priority=1)
	public void update(String username,String password) throws InterruptedException, IOException {
		
		System.out.println("inside update profile");
		String address1,address2;
	    Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(2000);
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Links link=new Links(driver);
		
		 //Creating softAssert object
		 SoftAssert softAssert = new SoftAssert();
		   
		
		link.clickProfile();
		Thread.sleep(2000);
		System.out.println("title="+driver.getTitle());
		softAssert.assertEquals(driver.getTitle(), "Profile - PHPTRAVELS");
		
		address1=ExcelUtils.getStringCellData(datafile, datasheet, 1, 0);
		System.out.println("address1"+address1);
		address2=ExcelUtils.getStringCellData(datafile, datasheet, 1, 1);
		System.out.println("address2"+address2);
		
		Address add= new Address(driver);
		
		add.setAddress1(address1);
		add.setAddress2(address2);
		Thread.sleep(2000);
		add.clickUpdate();
		Thread.sleep(3000);
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		System.out.println(driver.getCurrentUrl());
		if(driver.getCurrentUrl().equals("https://phptravels.net/account/profile/success")) 
		{
			softAssert.assertTrue(true);
			
		}
		else
			softAssert.assertTrue(false);	
		softAssert.assertAll();
		
	}
}
