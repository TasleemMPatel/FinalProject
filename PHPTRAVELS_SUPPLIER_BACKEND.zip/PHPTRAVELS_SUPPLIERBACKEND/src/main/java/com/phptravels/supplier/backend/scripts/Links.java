package com.phptravels.supplier.backend.scripts;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Links {

	WebDriver driver;
	@FindBy(xpath="//*[@id=\"drawerToggle\"]/i")
    private WebElement dashboard;
	
	@FindBy(xpath="//*[text()='Bookings']")
    private WebElement bookings;
	
	@FindBy(xpath="//*[@href=\"https://phptravels.net/api/admin/bookings/pending\"]")
    private WebElement pendingsbookings;
	
	@FindBy(xpath="//*[@href=\"https://phptravels.net/api/admin/bookings/confirmed\"]")
    private WebElement confirmedbookings;
	
	@FindBy(id="booking_status")
    private WebElement bookingstatus;
	
	@FindBy(xpath="//*[@id=\"drawerAccordion\"]/div/div/a[5]")
    private WebElement flights;
	
	//@FindBy(id="flightsmodule")
  //  private WebElement flightmodule;
	
	 public Links(WebDriver driver){
	    this.driver = driver;
	        
	    //This initElements method will create all WebElements
	    PageFactory.initElements(driver, this);
	 }
	    
	 public void clickDashboard() {
		 JavascriptExecutor js = (JavascriptExecutor)driver;
	     js.executeScript("arguments[0].click();", dashboard);
		
	 }
	 
	 public void clickBookings() {
	    	bookings.click();
	    }
	 
	 public void clickpendingBooking() {
		   
		   
		   pendingsbookings.click();
	   }
	 
	  public String getPendingBookings() {
		   
		   
		   return pendingsbookings.getText();
	   }
	  
	  public String getConfirmedBookings() {
		   
		   
		   return confirmedbookings.getText();
	   }
	  
	  public void selectConfirmed() {
		   	
		   	Select drpbookingstatus=new Select(bookingstatus);
		   	drpbookingstatus.selectByVisibleText("Confirmed");
		   	
		}
	  public void clickflightmodule() {
		   
		  flights.click(); 
		  /*System.out.println("flight"+flightmodule.isDisplayed());
		  if( flightmodule.isDisplayed()) {
		  flightmodule.click();
		  }else {
			  System.out.println("No flight module displayed");
		  }*/
	   }
}
