package com.phptravels.supplier.backend.utils;

import org.testng.annotations.DataProvider;

public class DataUtils {

	@DataProvider(name="dp1")
	public Object[][] getData() {
		
		return new Object[][] {{"supplier@phptravels.com","demosupplier"}};
	}
}
