package com.phptravels.supplier.backend.testcase;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravels.supplier.backend.scripts.Links;
import com.phptravels.supplier.backend.scripts.Login;
import com.phptravels.supplier.backend.utils.AppUtils;
import com.phptravels.supplier.backend.utils.DataUtils;

public class changeBookingStatus extends AppUtils{
	
	@Test(dataProvider="dp1",dataProviderClass=DataUtils.class,priority=3)
	public void change(String username,String password) throws InterruptedException {
				
		
	    Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(2000);
		//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Links link=new Links(driver);
		
		link.clickBookings();
		//Creating softAssert object
		SoftAssert softAssert = new SoftAssert();
		softAssert.assertEquals(driver.getTitle(), "All Bookings View");
		
		String entirependingBookingsString=link.getPendingBookings();
		
		//if ((entirependingBookingsString.substring(0, 1)).equals("")){
				
	   // }
		String pendingBookings=entirependingBookingsString.substring(0, 2);
		System.out.println("pendingBookings"+pendingBookings);
		pendingBookings.trim();
		System.out.println("pendingBookings"+pendingBookings.trim());
		int pendingBookingsValue=Integer.parseInt(pendingBookings.trim());
		System.out.println("pendingBookingsValue"+pendingBookingsValue);
		
		String entireconfirmedBookingsString=link.getConfirmedBookings();
		String confirmedBookings=entireconfirmedBookingsString.substring(0, 2);
		int confirmedBookingsValue=Integer.parseInt(confirmedBookings.trim());
		
		
		
		link.clickpendingBooking();
		softAssert.assertEquals(driver.getTitle(), "Pending Bookings View");
		Thread.sleep(3000);
		
		link.selectConfirmed();
		link.clickBookings();
		//driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
		String entirependingBookingsStringAfterChange=link.getPendingBookings();
		String pendingBookingsAfterChange=entirependingBookingsStringAfterChange.substring(0, 2);
		int pendingBookingsValueAfterChange=Integer.parseInt(pendingBookingsAfterChange.trim());
		
		String entireconfirmedBookingsStringAfterChange=link.getConfirmedBookings();
		String confirmedBookingsAfterChange=entireconfirmedBookingsStringAfterChange.substring(0, 2);
		int confirmedBookingsValueAfterChange=Integer.parseInt(confirmedBookingsAfterChange.trim());
		
		if(pendingBookingsValueAfterChange == pendingBookingsValue-1 && confirmedBookingsValueAfterChange == confirmedBookingsValue+1) {
			System.out.println("coming here");
			softAssert.assertTrue(true);
			
		}else
		{
			softAssert.assertTrue(false);
		}
		
		softAssert.assertAll();
		
	}

	


}

