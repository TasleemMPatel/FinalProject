package com.phptravels.supplier.backend.testcase;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import com.phptravels.supplier.backend.scripts.Links;
import com.phptravels.supplier.backend.scripts.Login;
import com.phptravels.supplier.backend.utils.AppUtils;
import com.phptravels.supplier.backend.utils.DataUtils;

public class checkModules extends AppUtils {
	
	@Test(dataProvider="dp1",dataProviderClass=DataUtils.class,priority=6)
	public void CheckModule(String username,String password) throws InterruptedException {
				
		Boolean flight = false;
		Boolean tours =false;
		Boolean visa =false;
		Boolean isDispalyed=false;
	    Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(3000);
		Thread.sleep(3000);
		Links link=new Links(driver);
		link.clickflightmodule();
		
		flight = driver.findElements(By.id("flightsmodule")).size() > 0;
		System.out.println("flight"+flight);
		if(!flight) {
			System.out.println("No flights module");
		}
		
	tours = driver.findElements(By.id("Tours")).size() > 0;
	System.out.println("tours"+tours);
	if(!tours) {
		System.out.println("No tours module");
	}else {
		
		System.out.println("Tours module available");
	}
	
	visa = driver.findElements(By.id("visamodule")).size() > 0;
	System.out.println("visa"+visa);
	if(!visa) {
		System.out.println("No visa module");
	}
	Thread.sleep(2000);
	driver.findElement(By.xpath("//*[@id=\"drawerAccordion\"]/div/div/a[7]")).click();
	Thread.sleep(2000);
	System.out.println("isDispalyed"+driver.getPageSource().contains("Bookings"));
	isDispalyed=driver.getPageSource().contains("Bookings");
    if(isDispalyed) {
    	System.out.println("Booking page is  displayed");
    }else {
    	System.out.println("Booking page is not displayed");
    }
	
	
	}
		
	}	
