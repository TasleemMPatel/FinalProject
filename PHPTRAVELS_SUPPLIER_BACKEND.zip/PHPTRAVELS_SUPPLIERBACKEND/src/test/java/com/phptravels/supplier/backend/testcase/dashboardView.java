package com.phptravels.supplier.backend.testcase;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.phptravels.supplier.backend.scripts.Links;
import com.phptravels.supplier.backend.scripts.Login;
import com.phptravels.supplier.backend.utils.AppUtils;
import com.phptravels.supplier.backend.utils.DataUtils;

public class dashboardView extends AppUtils {
	
	@Test(dataProvider="dp1",dataProviderClass=DataUtils.class,priority=6)
	public void CheckDashboardView(String username,String password) throws InterruptedException {
				
		
	    Login login= new Login(driver);
		login.setUserName(username);
		login.setPassword(password);
		login.clickLogin();
		Thread.sleep(3000);
		Links link=new Links(driver);
		link.clickDashboard();
		Thread.sleep(3000);
		
		System.out.println("isDispalyed"+driver.getPageSource().contains("Revenue Breakdown"));
		SoftAssert softassert =new SoftAssert();
		List l= driver.findElements(By.xpath("//*[contains(text(),'Sales overview & summary')]"));
		softassert.assertTrue(l.size() > 0 );
	      // verify list size
	      if ( l.size() > 0){
	         System.out.println("Text:  is present. ");
	      } else {
	         System.out.println("Text:  is not present. ");
	      }
		
		softassert.assertTrue(driver.getPageSource().contains("Revenue Breakdown") );
		
		softassert.assertAll();
   }
}
