package com.phptravels.supplier.backend.testcase;

import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.UnhandledAlertException;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.phptravels.supplier.backend.scripts.Login;
import com.phptravels.supplier.backend.utils.AppUtils;
import com.phptravels.supplier.backend.utils.ExcelUtils;

public class loginWithInvalidData extends AppUtils{

    
   String datafile = "E:\\PHPTRAVELS_SUPPLIER_BACKEND\\PHPTRAVELS_SUPPLIERBACKEND\\src\\main\\resources\\testData.xlsx";

	String datasheet = "Invalidlogin";

	@Test(priority=2)
	public void checkInvalidLogin() throws IOException, InterruptedException
	{
		
		
		int rowcount = ExcelUtils.getRowCount(datafile, datasheet);
		
		Login login; 
		
		String username,password;
		
		for(int i=1;i<=rowcount;i++)
		{
			try {
			username = ExcelUtils.getStringCellData(datafile, datasheet, i, 0);
			password = ExcelUtils.getStringCellData(datafile, datasheet, i, 1);
			//System.out.println(username);
		    //System.out.println(password);
			login = new Login(driver);
			login.setUserName(username);
		    login.setPassword(password);

		    Thread.sleep(2000);
		            
		    login.clickLogin();
		    Thread.sleep(3000);
		    
		    if(username.isEmpty()) {
		    	//System.out.println(username);
		    	Assert.assertTrue(driver.getPageSource().contains("Email field is required") );
		    }else if(password.isEmpty()) {
		    	//System.out.println(password);
		    	Assert.assertTrue(driver.getPageSource().contains("The Password field is required") );
		    	
		    }else  {
		    	//System.out.println("lastelse"+username);
		    	Assert.assertTrue(driver.getPageSource().contains("The Email field must contain a valid email address") || driver.getPageSource().contains("Invalid Login Credentials"));
		    	
		    }
		    
		    } catch (UnhandledAlertException f) {
		        try {
		            Alert alert = driver.switchTo().alert();
		            String alertText = alert.getText();
		            System.out.println(alertText);
		            alert.accept();
		            
		            System.out.println(alertText);
		        } catch (NoAlertPresentException e) {
		            e.printStackTrace();
		            System.out.println("No alert found on page, proceed with test.");
		            
		        }
		    }
			
		}
	}
		
		
		
	}
